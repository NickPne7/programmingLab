class Testo(str):
  
  def __len__(self):
    return len(self.split(" "))

mio_testo = Testo("ciao, oggi va tutto bene")

print(mio_testo)
print(len(mio_testo))