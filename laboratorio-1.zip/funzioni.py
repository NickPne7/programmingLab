
my_string = "a,b,c"
print(my_string.split(","))
print(my_string)

lista = [1,2,3]

lista.reverse()

print(lista)


print('Hello World!')


