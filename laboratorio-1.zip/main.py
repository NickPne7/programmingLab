def sum_csv(nomeFile):
  f = open(nomeFile,"r")
  for x in f:
    print(f.read(x))


print(sum_csv("shampoo_sales.csv"))
  