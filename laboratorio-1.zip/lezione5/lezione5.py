#lezione 5
#try except
#oggetti utili per mantenere lo stato e gestire le gerarchie

my_var = "nicola"

try:
   my_var = float(my_var)
except Exception as e: 
#e è un istanza dell'oggetto Exception ( in particolare della classe value error)

#guardare gli errori come mani che si alzano, il try except abbassa la mano, sennò arrivano fino all'interprete





   