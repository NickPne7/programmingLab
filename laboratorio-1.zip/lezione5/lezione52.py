
mio_paramentro = "ciao"
mio_parametro = float(mio_paramentro)


try:
  my_var = float(my_var)
except ValueError:
  print("non possso convertire my_var a valore numerico")