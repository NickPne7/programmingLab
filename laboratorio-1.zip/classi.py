import random


class Persona():
    def __init__(self, nome, cognome):
      self.nome = nome
      self.cognome = cognome

    def __str__(self):
      return "Persona '{} {}'".format(self.nome, self.cognome)


    def say_hi(self):
      #genera numero casuale tra 0,1 e 2
      random_number = random.randint(0,2)

    if random_number == 0:
      print("Ciao, sono {} {}".format(self.nome, self.nome))
    elif random_number == 1:
      #esempio2
    elif random_number == 2:
      #esempio3

persona = Persona("nicola", "pinat")
print(persona)
