class Csvfile():
  def __init__(self, name):
      self.name = name
      try:
          f = open(self.name, "r")
          f.close()
      except FileNotFoundError:
          print("Errore non c'è alcun file da aprire")

  def get_data(self):
      values = []
      file = open(self.name, "r")
      for line in file:
          elements = line.split(",")
          if elements[0] != "Date":
              p = [elements[0], elements[1][:-1]]
              values.append(p)
      file.close()
      return values

class NumericalCSVfile(Csvfile):

file = NumericalCSVfile("shampoo_sales.csv")
print(file.conversioneFloat())